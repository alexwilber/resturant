class CreateReviews < ActiveRecord::Migration[5.0]
  def change
    create_table :reviews do |t|
      t.timestamps
      t.text :body
      t.integer :user_id, index: true, reference: true
      t.integer :restaurant_id, index: true, reference: true
    end
  end
end
