$(document).on('turbolinks:load', function() {
        $('.edit_link').click(function(event) {
            event.preventDefault();
            $(this).next('.edit_review').toggle() }
        )
});