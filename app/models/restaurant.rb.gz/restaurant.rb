class Restaurant < ApplicationRecord
  has_many :reviews
end
